TOKEN = '6119823083:AAF2AK2gGReVidsuW7WB13WevFdTQegIqL0'

keys = {
    'евро' : 'EUR',
    'рубль' : 'RUB',
    'доллар' : 'USD',
}